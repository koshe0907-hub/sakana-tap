さかなタップ！Ver.4

入っている機能
・12種類の魚
・魚ごとの描き分け
・コイン
・レア魚ガチャ
・魚図鑑
・レベル
・デイリーボーナス
・放置報酬
・自動セーブ
・オフライン対応
・ホーム画面追加対応

GitHubでの更新方法
1. sakana-tap を開く
2. Code横の「…」→ Upload file
3. このZIPを解凍した中の以下3ファイルを選ぶ
   index.html
   manifest.webmanifest
   sw.js
4. Commit changes
5. Netlifyが自動更新
